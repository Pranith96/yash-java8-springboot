@FunctionalInterface
public interface PrintData {
	public void print();
}
